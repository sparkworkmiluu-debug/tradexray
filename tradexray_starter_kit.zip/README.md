# TradeXRay: Open-Source Retail Trade Auditor & Market Microstructure Coach 🔬📈

[![License: Apache-2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python: 3.9+](https://img.shields.io/badge/python-3.9+-brightgreen.svg)](https://www.python.org/)
[![SEC Compliance: Rule 605/606](https://img.shields.io/badge/SEC%20Standard-Rule%20605%2F606-cyan.svg)]()
[![Live Demo](https://img.shields.io/badge/Live%20Demo-GitHub%20Pages-success.svg)](https://your-username.github.io/tradexray/)

**TradeXRay** is a dual-engine quantitative finance platform that demystifies equity market microstructure for everyday retail investors while providing an institutional-grade **Transaction Cost Analysis (TCA)** engine to audit broker execution quality against the National Best Bid and Offer (NBBO).

---

## 📌 The Problem

Over **$120 billion** in retail stock order flow is routed through wholesale market makers every year. Under commission-free trading models, retail brokers monetize orders via **Payment for Order Flow (PFOF)**, sending trades to internalizers like **Citadel Securities**, **Virtu Financial**, and **Two Sigma**:
* Retail investors assume trading is 100% free, but frequently surrender hidden edge to wide bid-ask spreads.
* Zero third-party audit tools exist for everyday retail investors to evaluate whether their broker delivered fair **Price Improvement** or costly **Slippage**.
* Retail traders routinely suffer from **Adverse Selection** (buying at local peaks immediately before predatory price drops).

**TradeXRay bridges this information asymmetry.**

---

## 🚀 Key Features

### 🎓 1. The Pre-Trade Coach (Beginner Layer)
* **Interactive Order Simulator**: Test the trade-offs between instant-fill **Market Orders** (paying spread friction) vs. **Limit Orders at Midpoint** (saving spread costs).
* **Market Regimes Clock**: Traffic-light volatility indicators showing why trading during the **9:30 AM – 10:00 AM Open** incurs up to **2.8x wider spreads** compared to midday calm.
* **Plain-English Jargon Decoder**: Demystifies NBBO, PFOF, Internalization, and Spread Dynamics through intuitive real-world analogies.

### 🔬 2. The Trade X-Ray (Institutional TCA Layer)
* **Sub-Penny Effective Spread Calculation**: Measures exact distance from the NBBO midpoint under SEC Rule 605 standards:
  $$\text{Effective Spread} = 2 \times |P_{\text{fill}} - M_{\text{NBBO}}|$$
* **Price Improvement & E/Q Ratio**: Calculates cents-per-share and total dollar savings against the posted quote.
* **Wholesaler PFOF Fingerprinting**: Identifies which high-frequency market maker internalized the order based on SEC Rule 606 disclosures.
* **Post-Trade Markout Curve (1s, 5s, 15s, 60s)**: Graphs the post-execution price drift to detect **Adverse Selection** (dumping inventory right before a momentum drop).

### 🗺️ 3. The Wall Street Plumbing Map
* Animated 5-stage life cycle tracing an order from mobile app tap, to broker router, to wholesaler internalization, to SIP consolidated tape, and DTCC T+1 clearing.

---

## 🛠️ Quickstart

### 1. Run the Python TCA Engine
```bash
# Clone the repository
git clone https://github.com/your-username/tradexray.git
cd tradexray

# Run an audit on a 100-share NVDA buy order
python tca_engine.py --ticker NVDA --shares 100 --fill 125.02 --bid 124.95 --ask 125.05 --broker Robinhood
```

**Output:**
```text
================================================================================
  TRADEXRAY TRANSACTION COST ANALYSIS (TCA) REPORT
  SEC Rule 605 / 606 Execution Audit • Trade ID: TXR-9042
================================================================================
  Ticker & Side    : 100 shares of NVDA (BUY)
  Broker & Route   : Robinhood ──► Citadel Securities LLC (~38% routing share)
  Execution Price  : $125.02
  Benchmark NBBO   : Bid $124.95 | Mid $125.00 | Ask $125.05
--------------------------------------------------------------------------------
  QUANTITATIVE EXECUTION METRICS:
  • Quoted Spread          : $0.100 (8.0 bps)
  • Effective Spread       : $0.040 (3.2 bps)
  • Effective/Quoted (E/Q) : 40.0%  (Institutional target < 100%)
  • Price Improvement      : +$0.030 / share
  • Net Dollar Impact      : +$3.00
  • Estimated Broker PFOF  : ~$0.18
  • Execution Quality Grade: A+ (Superior Improvement)
--------------------------------------------------------------------------------
  POST-TRADE MARKOUT TRAJECTORY (Adverse Selection Analysis):
    - t_0    : $125.02  (+$0.00)
    - t_1s   : $125.03  (+$0.01)
    - t_5s   : $125.04  (+$0.02)
    - t_15s  : $125.05  (+$0.03)
    - t_60s  : $125.06  (+$0.04)
  • Adverse Selection Flag : ✅ NEGATIVE (Clean Execution)
  • Analyst Assessment    : Optimal Execution: Trader captured meaningful price improvement without adverse post-trade drift.
================================================================================
```

### 2. Launch the Web Visualizer
Simply open `index.html` in any web browser, or host it via GitHub Pages.

---

## 📂 Repository Structure

```text
├── tca_engine.py              # Core Python quantitative TCA & microstructure engine
├── index.html                 # Interactive web dashboard (Simulator, Auditor, Map)
├── TradeXRay_Presentation.pptx# Executive architectural & quantitative slide deck
├── README.md                  # Project documentation & mathematical specifications
└── requirements.txt           # Minimal standard dependencies
```

---

## 📄 License

Distributed under the Apache-2.0 License. See `LICENSE` for more information.
